package com.assignment.postapi.controller;

import java.time.LocalTime;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.postapi.enity.User;

@RestController
public class UserController {

	/* Saving Users */
	@PostMapping(value = "/users")
	public String saveUser(@RequestBody User user) {

		String key = user.getName() + ":" + user.getEmail();

		if (!User.userRepo.containsKey(key)) {
			user.setTime(LocalTime.now());
			User.userRepo.put(key, user);
			return "User Saved";
		} else {
			User user1 = User.userRepo.get(key);
			user1.setTime(LocalTime.now());
			return "User already exists, Hence time has been modified!!";
		}
	}
}
