package com.assignment.postapi.enity;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

public class User {

	private String name;
	private String email;
	private LocalTime time;

	/* User Data */
	public static Map<String, User> userRepo = new HashMap<>();

	/* Saving Sample Data */
	static {
		User user1 = new User("Aayush", "aayush@gmail.com", LocalTime.now());
		userRepo.put(user1.getName() + ":" + user1.getEmail(), user1);

		User user2 = new User("Keshav", "keshav@gmail.com", LocalTime.now());
		userRepo.put(user2.getName() + ":" + user2.getEmail(), user2);
	}

	public User() {
	}

	public User(String name, String email, LocalTime time) {
		this.name = name;
		this.email = email;
		this.time = time;
	}

	/* Getters and Setters */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalTime getTime() {
		return time;
	}

	public void setTime(LocalTime time) {
		this.time = time;
	}
}
